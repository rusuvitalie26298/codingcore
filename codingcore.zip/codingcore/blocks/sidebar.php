<div class="col-1">
	<h1> Sidebar </h1>
    <div class="text-end">
        <button type="button" class="btn">Cautare</button>
        <button type="button" class="btn btn-warning">Widget</button>
	</div>
</div>