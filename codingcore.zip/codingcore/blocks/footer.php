<div class="footer">

	<div class="container">

		<div class="footer-content">
			<div class="logo">

				<a href="index.php" class="logo-a"><img src="logo.png" height="27" alt="CodingCore" class="logo-img"> Coding Core 
				</a>

			</div>

			<div class="footer-text">
				
				Copyright © 2022. All Rights Reserved by Coding Core

			</div>

		</div>

	</div>

</div>


</body>
</html>