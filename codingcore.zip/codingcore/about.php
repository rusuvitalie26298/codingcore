<?php include 'blocks/header.php'; ?>

<?php include 'blocks/footer.php'; ?>